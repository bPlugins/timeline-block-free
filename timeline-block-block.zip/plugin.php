<?php
/**
 * Plugin Name: Timeline Block
 * Description: Display timeline content on your site. 
 * Version: 1.5.0
 * Requires at least: 6.5
 * Tested up to: 6.9
 * Author: bPlugins
 * Author URI: https://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: timeline-block
 * Domain Path:  /languages
 */ 

// ABS PATH
if (!defined('ABSPATH')) {
  exit;
}

if (function_exists('tlgb_fs')) {
  tlgb_fs()->set_basename(false, __FILE__);
} else {
  // Constant
  define('TLGB_VERSION', isset($_SERVER['HTTP_HOST']) && 'localhost' === $_SERVER['HTTP_HOST'] ? time() : '1.5.0');
  define('TLGB_DIR_URL', plugin_dir_url(__FILE__));
  define('TLGB_DIR_PATH', plugin_dir_path(__FILE__));
  define('TLGB_HAS_FREE', 'timeline-block-block/plugin.php' === plugin_basename(__FILE__));
  define('TLGB_HAS_PRO', 'timeline-block-block-pro/plugin.php' === plugin_basename(__FILE__));
  
  if (!function_exists('tlgb_fs')) {
    function tlgb_fs() {
      global $tlgb_fs;

      if (!isset($tlgb_fs)) {
        
        require_once TLGB_DIR_PATH . '/vendor/freemius-lite/start.php';

        $tlgbConfig = [
          'id' => '17342',
          'slug' => 'timeline-block-block',
          'premium_slug' => 'timeline-block-block-pro',
          'type' => 'plugin',
          'public_key' => 'pk_624005a9d0c56ff46db6602f5f730',
          'is_premium' => false,
          'menu' => [
              'slug' => 'edit.php?post_type=timeline_block',
              'first-path' => "edit.php?post_type=timeline_block&page=tlgb-dashboard#/welcome",
              'contact' => false,
              'support' => false,
              'affiliation' => false
          ],
        ];
        $tlgb_fs = fs_lite_dynamic_init($tlgbConfig);
      }

      return $tlgb_fs;
    }

    tlgb_fs();
    do_action('tlgb_fs_loaded');
  }
  require_once TLGB_DIR_PATH. 'includes/class-tlgb-main.php';
  new TLGBTimeline();
  
} 